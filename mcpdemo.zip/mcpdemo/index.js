import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import axios from "axios";
import { z } from "zod";
import fs from "fs-extra";
import path from "path";
import { spawn } from "child_process";
import { Groq } from "groq-sdk";
import dotenv from "dotenv";

dotenv.config();




const server = new McpServer({
  name: "Demo",
  version: "1.0.0"
});

server.tool(
    "append-feature-query",
    "Appends an implementation prompt to a user-provided WEAT or feature to generate step-by-step guidance with structure and tech stack. ",
    {
      feature: z.string()
    },
    async ({ feature }) => {
      const promptSuffix =
        " complete this feature step by step as mentioned with proper folder structure and file structure with proper modularization also and a proper tech stack of your conveinence to build this completely and try to make use of the minimal folders and try to avoid redundancy and store the directory in my desktop folder";
  
      const modifiedQuery = `${feature.trim()}${promptSuffix}`;
  
      return {
        content: [
          {
            type: "text",
            text: modifiedQuery,
          },
        ],
      };
    }
  );

  server.tool(
    "generate-and-run-jest-tests",
    "Generates a Jest test suite for a given JavaScript file, writes it to the same directory, executes the tests, and logs the results.",
    {
      filePath: z.string()
    },
    async ({ filePath }) => {
    
  
      const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });
  
      function readSource(filePath) {
        if (!fs.existsSync(filePath)) throw new Error(`Source file not found: ${filePath}`);
        return fs.readFileSync(filePath, "utf-8");
      }
  
      async function generateTestCode(sourceCode, fileName) {
        const prompt = `Generate a Jest test suite for the following JavaScript code:\n\n${sourceCode}\n\nFile name: ${fileName}\nOutput ONLY valid test code. DO NOT include markdown backticks or explanation.`;
        const completion = await groq.chat.completions.create({
          model: 'llama-3.3-70b-versatile',
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.3,
        });
        const responseText = completion.choices[0].message.content;
        return responseText.replace(/```(?:\w+)?/g, "").trim(); // Remove accidental backticks
      }
  
      function writeTestFile(originalFile, testCode) {
        const fileName = path.basename(originalFile);
        const testFileName = fileName.replace(".js", ".test.js");
        const testDir = path.dirname(originalFile);
        const testPath = path.join(testDir, testFileName);
  
        fs.writeFileSync(testPath, testCode);
        return testPath;
      }
  
      function runTestsAndLog() {
        return new Promise((resolve, reject) => {
          const outputLog = fs.createWriteStream("test-report.log");
          const jest = spawn("npx", ["jest", "--json", "--outputFile=jest-results.json", "--coverage"], {
            shell: true,
          });
  
          jest.stdout.on("data", (data) => outputLog.write(data.toString()));
          jest.stderr.on("data", (data) => outputLog.write(data.toString()));
  
          jest.on("exit", (code) => {
            outputLog.end();
  
            if (fs.existsSync("jest-results.json")) {
              const report = JSON.parse(fs.readFileSync("jest-results.json", "utf-8"));
              const failedTests = report.testResults.flatMap((file) =>
                file.assertionResults
                  .filter((t) => t.status === "failed")
                  .map((t) => `❌ ${t.fullName}`)
              );
  
              if (failedTests.length) {
                fs.appendFileSync("test-report.log", `\n\n🚨 Failed Test Cases:\n${failedTests.join("\n")}\n`);
                reject("❌ Some test cases failed. See test-report.log for details.");
              } else {
                fs.appendFileSync("test-report.log", "\n✅ All test cases passed.\n");
                resolve("✅ All tests passed.");
              }
            } else {
              reject("❌ Jest output not found.");
            }
          });
        });
      }
  
      try {
        const sourceCode = readSource(filePath);
        const testCode = await generateTestCode(sourceCode, path.basename(filePath));
        const testFilePath = writeTestFile(filePath, testCode);
        const testResult = await runTestsAndLog();
  
        return {
          content: [
            { type: "text", text: `✅ Test file generated at: ${testFilePath}` },
            { type: "text", text: testResult }
          ],
        };
      } catch (err) {
        return {
          content: [
            { type: "text", text: `🚨 Error: ${err.message}` }
          ],
        };
      }
    }
  );

  server.tool(
    "full-feature-pipeline",
    "Expands a feature prompt and generates & tests corresponding Jest test code in one step.",
    {
      feature: z.string(),
      filePath: z.string()
    },
    async ({ feature, filePath }) => {
      try {
        // Step 1: Call append-feature-query
        const appendedResult = await server.invoke("append-feature-query", {
          feature
        });
  
        const detailedPrompt = appendedResult.content.find((c) => c.type === "text")?.text;
  
        // Step 2: Optionally show the expanded prompt
        const promptMessage = `📝 Expanded Prompt:\n${detailedPrompt}`;
  
        // Step 3: Call generate-and-run-jest-tests
        const testResult = await server.invoke("generate-and-run-jest-tests", {
          filePath
        });
  
        const testMessages = testResult.content;
  
        return {
          content: [
            { type: "text", text: promptMessage },
            ...testMessages
          ]
        };
      } catch (err) {
        return {
          content: [
            {
              type: "text",
              text: `🚨 Pipeline Error: ${err.message || "Something went wrong."}`
            }
          ]
        };
      }
    }
  );
  
  

// Start receiving messages on stdin and sending messages on stdout
const transport = new StdioServerTransport();
await server.connect(transport);